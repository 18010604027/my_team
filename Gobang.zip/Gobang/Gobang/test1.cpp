﻿// test1.cpp: 实现文件
//

#include "pch.h"
#include "Gobang.h"
#include "test1.h"
#include "afxdialogex.h"


// test1 对话框

IMPLEMENT_DYNAMIC(test1, CDialogEx)

test1::test1(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG4, pParent)
{

}

test1::~test1()
{
}

void test1::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON1, butrron_);
	DDX_Control(pDX, IDC_STATICa, board);
}


BEGIN_MESSAGE_MAP(test1, CDialogEx)
END_MESSAGE_MAP()


// test1 消息处理程序
